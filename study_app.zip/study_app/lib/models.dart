class StudyClass {
  final String name;
  final List<StudySubject> subjects;

  StudyClass({required this.name, required this.subjects});
}

class StudySubject {
  final String name;
  final List<StudyChapter> chapters;

  StudySubject({required this.name, required this.chapters});
}

class StudyChapter {
  final String name;
  final List<StudyContent> contents;

  StudyChapter({required this.name, required this.contents});
}

class StudyContent {
  final String type;
  final List<StudyFile> files;

  StudyContent({required this.type, required this.files});
}

class StudyFile {
  final String name;
  final String path;
  final String type;

  StudyFile({required this.name, required this.path, required this.type});
}


