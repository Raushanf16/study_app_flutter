import 'package:flutter/material.dart';
import 'package:study_app/models.dart';
import 'package:study_app/widgets/pdf_viewer_page.dart';
import 'package:study_app/widgets/video_player_page.dart';

class ClassListView extends StatelessWidget {
  final List<StudyClass> studyClasses;

  const ClassListView({super.key, required this.studyClasses});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: studyClasses.length,
      itemBuilder: (context, index) {
        final studyClass = studyClasses[index];
        return Card(
          margin: const EdgeInsets.all(8.0),
          child: ExpansionTile(
            title: Text(
              studyClass.name.replaceAll("_", " ").toUpperCase(),
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            children: studyClass.subjects.map((subject) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: ExpansionTile(
                  title: Text(
                    subject.name.replaceAll("_", " ").toUpperCase(),
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  children: subject.chapters.map((chapter) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Card(
                        margin: const EdgeInsets.symmetric(vertical: 4.0),
                        child: ListTile(
                          title: Text(
                            chapter.name.replaceAll("_", " ").toUpperCase(),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          onTap: () {
                            // Navigate to chapter detail page
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ChapterDetailPage(chapter: chapter),
                              ),
                            );
                          },
                        ),
                      ),
                    );
                  }).toList(),
                ),
              );
            }).toList(),
          ),
        );
      },
    );
  }
}

class ChapterDetailPage extends StatelessWidget {
  final StudyChapter chapter;

  const ChapterDetailPage({super.key, required this.chapter});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: chapter.contents.length,
      child: Scaffold(
        appBar: AppBar(
          title: Text(chapter.name.replaceAll("_", " ").toUpperCase()),
          bottom: TabBar(
            tabs: chapter.contents.map((content) => Tab(text: content.type)).toList(),
          ),
        ),
        body: TabBarView(
          children: chapter.contents.map((content) {
            return ListView.builder(
              itemCount: content.files.length,
              itemBuilder: (context, index) {
                final file = content.files[index];
                return Card(
                  margin: const EdgeInsets.all(8.0),
                  child: ListTile(
                    title: Text(file.name),
                    subtitle: Text(file.path),
                    onTap: () {
                      if (file.type == 'pdf') {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PdfViewerPage(pdfPath: file.path),
                          ),
                        );
                      } else if (file.type == 'mp4' || file.type == 'mkv' || file.type == 'avi') {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => VideoPlayerPage(videoPath: file.path),
                          ),
                        );
                      } else {
                        print("Opening file: ${file.path}");
                      }
                    },
                  ),
                );
              },
            );
          }).toList(),
        ),
      ),
    );
  }
}


