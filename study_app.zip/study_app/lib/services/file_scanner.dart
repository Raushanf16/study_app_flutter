import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:glob/glob.dart';
import 'package:glob/list_local_fs.dart';
import '../models.dart';

class FileScannerService {
  static const String _basePath = '/storage/emulated/0/study_materials/';

  Future<List<StudyClass>> scanStudyMaterials() async {
    List<StudyClass> classes = [];

    final baseDir = Directory(_basePath);
    if (!await baseDir.exists()) {
      print('Base directory does not exist: $_basePath');
      return [];
    }

    final classGlobs = Glob('$_basePath/class_*');
    for (var classDir in classGlobs.listSync(followLinks: false)) {
      if (classDir is Directory) {
        final className = classDir.path.split('/').last;
        List<StudySubject> subjects = [];

        final subjectGlobs = Glob('${classDir.path}/sub_*');
        for (var subjectDir in subjectGlobs.listSync(followLinks: false)) {
          if (subjectDir is Directory) {
            final subjectName = subjectDir.path.split('/').last;
            List<StudyChapter> chapters = [];

            final chapterGlobs = Glob('${subjectDir.path}/ch_*');
            for (var chapterDir in chapterGlobs.listSync(followLinks: false)) {
              if (chapterDir is Directory) {
                final chapterName = chapterDir.path.split('/').last;
                List<StudyContent> contents = [];

                // Scan for DPPs
                final dppFiles = await _scanContent(chapterDir.path, 'con_dpp', 'dpp_', 'pdf');
                if (dppFiles.isNotEmpty) {
                  contents.add(StudyContent(type: 'DPPs', files: dppFiles));
                }

                // Scan for Notes
                final notesFiles = await _scanContent(chapterDir.path, 'con_notes', 'notes_', 'pdf');
                if (notesFiles.isNotEmpty) {
                  contents.add(StudyContent(type: 'Notes', files: notesFiles));
                }

                // Scan for Lectures
                final lectureFiles = await _scanContent(chapterDir.path, 'con_lectures', 'l_', 'mp4|mkv|avi');
                if (lectureFiles.isNotEmpty) {
                  contents.add(StudyContent(type: 'Lectures', files: lectureFiles));
                }

                if (contents.isNotEmpty) {
                  chapters.add(StudyChapter(name: chapterName, contents: contents));
                }
              }
            }
            if (chapters.isNotEmpty) {
              subjects.add(StudySubject(name: subjectName, chapters: chapters));
            }
          }
        }
        if (subjects.isNotEmpty) {
          classes.add(StudyClass(name: className, subjects: subjects));
        }
      }
    }
    return classes;
  }

  Future<List<StudyFile>> _scanContent(String chapterPath, String contentTypeFolder, String filePrefix, String fileExtensions) async {
    List<StudyFile> files = [];
    final contentDirPath = '$chapterPath/$contentTypeFolder';
    final contentDir = Directory(contentDirPath);

    if (await contentDir.exists()) {
      final fileGlob = Glob('$contentDirPath/$filePrefix*.{$fileExtensions}');
      for (var file in fileGlob.listSync(followLinks: false)) {
        if (file is File) {
          files.add(StudyFile(
            name: file.path.split('/').last,
            path: file.path,
            type: file.path.split('.').last,
          ));
        }
      }
    }
    return files;
  }
}


