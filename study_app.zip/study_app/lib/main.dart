import 'package:flutter/material.dart';
import 'package:study_app/services/file_scanner.dart';
import 'package:study_app/models.dart';
import 'package:study_app/widgets/class_list_view.dart';
import 'package:permission_handler/permission_handler.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Study App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<StudyClass> _studyClasses = [];
  bool _isLoading = true;
  bool _hasPermission = false;

  @override
  void initState() {
    super.initState();
    _requestPermissions();
  }

  Future<void> _requestPermissions() async {
    var status = await Permission.storage.status;
    if (!status.isGranted) {
      status = await Permission.storage.request();
    }

    if (status.isGranted) {
      setState(() {
        _hasPermission = true;
      });
      _scanFiles();
    } else {
      setState(() {
        _hasPermission = false;
        _isLoading = false;
      });
    }
  }

  Future<void> _scanFiles() async {
    setState(() {
      _isLoading = true;
    });
    final scanner = FileScannerService();
    _studyClasses = await scanner.scanStudyMaterials();
    setState(() {
      _isLoading = false;
    });
    // For now, just print the scanned data to the console
    _studyClasses.forEach((studyClass) {
      print('Class: ${studyClass.name}');
      studyClass.subjects.forEach((subject) {
        print('  Subject: ${subject.name}');
        subject.chapters.forEach((chapter) {
          print('    Chapter: ${chapter.name}');
          chapter.contents.forEach((content) {
            print('      Content Type: ${content.type}');
            content.files.forEach((file) {
              print('        File: ${file.name} (${file.path})');
            });
          });
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Study Materials'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : !_hasPermission
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Storage permission denied. Please enable it in settings.'),
                      ElevatedButton(
                        onPressed: () {
                          openAppSettings();
                        },
                        child: const Text('Open Settings'),
                      ),
                    ],
                  ),
                )
              : _studyClasses.isEmpty
                  ? const Center(child: Text('No study materials found.'))
                  : ClassListView(studyClasses: _studyClasses),
      floatingActionButton: FloatingActionButton(
        onPressed: _scanFiles,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}


